
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//  @WebServlet("/login")
public class contact extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        RequestDispatcher dispatcher = null;
        Connection con = null;
        HttpSession session = request.getSession();
        int userid;
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String message = request.getParameter("message");
        if(session.getAttribute("name") != null){
            userid = Integer.parseInt((String) session.getAttribute("userid"));
        }
        else{
            userid = 000;
        }
        try {

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/desem6", "root", "");

            String query = "insert into contact(name ,email ,message,userid) values(?,?,?,?)";
            
            
            PreparedStatement stmt = con.prepareStatement(query);
             stmt.setString(1, name);
             stmt.setString(2, email);
             stmt.setString(3, message);
             stmt.setInt(4,userid );
            
            int count = stmt.executeUpdate();
            if(count > 0){
                session.setAttribute("contactcheck", "true");
                dispatcher = request.getRequestDispatcher("/contact.jsp");
            }else {
                session.setAttribute("contactcheck", "false");
                dispatcher = request.getRequestDispatcher("/contact.jsp");
            }
           
           
            
        } catch (Exception e) {
            e.printStackTrace(); 
            session.setAttribute("contactcheck", "false");
                dispatcher = request.getRequestDispatcher("/contact.jsp");

        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(registration.class.getName()).log(Level.SEVERE, null, ex);
            } dispatcher.forward(request, response);

        }

    }
}
