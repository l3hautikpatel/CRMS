
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//  @WebServlet("/login")
public class logout extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        RequestDispatcher dispatcher = null;
    
        HttpSession session = request.getSession();


            if(session.getAttribute("name") != null){
                session.removeAttribute("name");
                session.removeAttribute("logincheck");
                session.invalidate();
                dispatcher = request.getRequestDispatcher("index.jsp");
            } else {
                session.setAttribute("logincheck","false");
                dispatcher = request.getRequestDispatcher("profile.jsp");

            }
            dispatcher.forward(request, response);

      

        }

    }
