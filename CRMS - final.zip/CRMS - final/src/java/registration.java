    
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//  @WebServlet("/registration")
public class registration extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();

        out.println("this is java page");
        String fristname = request.getParameter("fristname");
        String lastname = request.getParameter("lastname");
        String emailid = request.getParameter("emailid");
        String username = request.getParameter("username");
        int age = Integer.parseInt(request.getParameter("age"));
        String gender = request.getParameter("gender");
        String password = request.getParameter("password");

        RequestDispatcher dispatcher = null;
        Connection con = null;
        try {

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/desem6", "root", "");

            String query = "insert into user(fristname ,lastname, email, username ,age ,gender , password ) values(?,?,?,?,?,?,?)";

            PreparedStatement stmt = con.prepareStatement(query);

            stmt.setString(1, fristname);
            stmt.setString(2, lastname);
            stmt.setString(3, emailid);
            stmt.setString(4, username);
            stmt.setInt(5, age);
            stmt.setString(6, gender);
            stmt.setString(7, password);

            int count = stmt.executeUpdate(); // it returns no of rows affected.

            if (count > 0) {
                session.setAttribute("registrationcheck", "true");
                request.setAttribute("status", "success");
                dispatcher = request.getRequestDispatcher("/profile.jsp");
            } else {
                request.setAttribute("status", "fail");
                session.setAttribute("registrationcheck", "false");
                dispatcher = request.getRequestDispatcher("/profile.jsp");
            }

        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("registrationcheck", "false");
            dispatcher = request.getRequestDispatcher("/profile.jsp");

        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(registration.class.getName()).log(Level.SEVERE, null, ex);
                session.setAttribute("registrationcheck", "false");
                dispatcher = request.getRequestDispatcher("/profile.jsp");
            }
            dispatcher.forward(request, response);
        }

    }

}
