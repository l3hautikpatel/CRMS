
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@MultipartConfig()
public class sell extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        RequestDispatcher dispatcher = null;

        Part img = request.getPart("image");
        InputStream imgdata = img.getInputStream();

        String carname = request.getParameter("carname");
        int pri = Integer.parseInt(request.getParameter("price"));
        String price = pri + " lakh";
        String engine = request.getParameter("engine");
        String milage = request.getParameter("milage");
        String gear = request.getParameter("gear");
        String fuletype = request.getParameter("fuletype");
        String seating = request.getParameter("seating");
        String carfor = "sell";
        String status = "active";
        int ownerid = Integer.parseInt((String) session.getAttribute("userid"));

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = null;
            con = DriverManager.getConnection("jdbc:mysql://localhost/desem6", "root", "");

            PreparedStatement stmt;
            String query = "insert into carinformation(carname,fuletype,seating,price,carfor,gear,engine,milage,image,ownerid,status) values(?,?,?,?,?,?,?,?,?,?,?)";
            stmt = con.prepareStatement(query);
            stmt.setString(1, carname);
            stmt.setString(2, fuletype);
            stmt.setString(3, seating);
            stmt.setString(4, price);
            stmt.setString(5, carfor);
            stmt.setString(6, gear);
            stmt.setString(7, engine);
            stmt.setString(8, milage);
            stmt.setBlob(9, imgdata);
            stmt.setInt(10, ownerid);
            stmt.setString(11, status);

            int count = stmt.executeUpdate();
            if (count > 0) {
                session.setAttribute("sellcheck", "true");
                dispatcher = request.getRequestDispatcher("profile.jsp");

            } else {
                session.setAttribute("sellcheck", "false");
                dispatcher = request.getRequestDispatcher("error.jsp");

            }

        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("sellcheck", "false");
            dispatcher = request.getRequestDispatcher("error.jsp");
        }
         dispatcher.forward(request, response);
    }

}
