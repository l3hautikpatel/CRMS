
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//  @WebServlet("/login")
public class payment extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String mode = request.getParameter("mode");
        String cardno = request.getParameter("cardno");
        String expire = request.getParameter("expire");
        String cvv = request.getParameter("cvv");
        String cardname = request.getParameter("cardname");
        String carfor = request.getParameter("carfor");
        String at = "customer";
        String deactive = "deactive";
        int carid = Integer.parseInt(request.getParameter("carid"));
        int userid = Integer.parseInt(request.getParameter("userid"));

        out.println(mode + cardno + expire + cvv + carid + cardname + userid);

        RequestDispatcher dispatcher = null;
        Connection con = null;
        HttpSession session = request.getSession();

        try {

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/desem6", "root", "");

            String query = "insert into booking(userid ,carid, mode, cardno ,expire ,cvv , cardname ,at) values(?,?,?,?,?,?,?,?)";

            PreparedStatement stmt = con.prepareStatement(query);

            stmt.setInt(1, userid);
            stmt.setInt(2, carid);
            stmt.setString(3, mode);
            stmt.setString(4, cardno);
            stmt.setString(5, expire);
            stmt.setString(6, cvv);
            stmt.setString(7, cardname);
            stmt.setString(8, at);

            int count = stmt.executeUpdate();

            if (carfor.equals("rent")) {
                String sql1 = "update carinformation set status='deactive' where carid = ? ";
                PreparedStatement p1 = con.prepareStatement(sql1);
                p1.setInt(1, carid);
            count += p1.executeUpdate();
            String sql11 = "update carinformation set clientid = ? where carid = ? ";
                PreparedStatement p11 = con.prepareStatement(sql11);
                p11.setInt(1, userid);
                p11.setInt(2, carid);
            count += p11.executeUpdate();
            } else {
                String sql2 = "update carinformation set status='deactive' where carid = ? ";
                PreparedStatement p2 = con.prepareStatement(sql2);
                p2.setInt(1, carid);
            count += p2.executeUpdate();
            String sql112 = "update carinformation set clientid = ? where carid = ? ";
                PreparedStatement p112 = con.prepareStatement(sql112);
                p112.setInt(1, userid);
                p112.setInt(2, carid);
            count += p112.executeUpdate();
                String sql22 = "update carinformation set ownerid=? where carid = ? ";
                PreparedStatement p22 = con.prepareStatement(sql22);
                p22.setInt(1, userid);
                p22.setInt(2, carid);
            count += p22.executeUpdate();
            
            }

            if (count > 0) {
                session.setAttribute("paymentcheck", "true");
                dispatcher = request.getRequestDispatcher("profile.jsp");

            } else {
                session.setAttribute("paymentcheck", "false");
                dispatcher = request.getRequestDispatcher("error.jsp");

            }

        } catch (Exception e) {
            e.printStackTrace();

            session.setAttribute("paymentcheck", "false");
            dispatcher = request.getRequestDispatcher("error.jsp");
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(registration.class.getName()).log(Level.SEVERE, null, ex);
            }

            dispatcher.forward(request, response);

        }

    }
}
