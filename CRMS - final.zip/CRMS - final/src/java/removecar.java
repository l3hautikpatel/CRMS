
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//  @WebServlet("/login")
public class removecar extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("hello bhautik inside post");

        RequestDispatcher dispatcher = null;
        Connection con = null;
        HttpSession session = request.getSession();

        int carid = Integer.parseInt(request.getParameter("carid"));
       
                out.println(carid);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/desem6", "root", "");
            String sql = "delete from carinformation where carid = ?";
            PreparedStatement p = con.prepareStatement(sql);
            p.setInt(1, carid);
            int count = p.executeUpdate();
            if (count > 0) {
                session.setAttribute("removecheck", "true");
                dispatcher = request.getRequestDispatcher("profile.jsp");
                 out.println("all run ok");
            } else {
                session.setAttribute("removecheck", "false");
                dispatcher = request.getRequestDispatcher("error.jsp");

            }

        } catch (Exception e) {
            e.getMessage();
            session.setAttribute("removecheck", "false");
            dispatcher = request.getRequestDispatcher("error.jsp");

        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(registration.class.getName()).log(Level.SEVERE, null, ex);
            }

            dispatcher.forward(request, response);

        }

    }
    
    
    
     @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("hello bhautik inside get");

        RequestDispatcher dispatcher = null;
        Connection con = null;
        HttpSession session = request.getSession();

        int carid = Integer.parseInt(request.getParameter("carid"));
       
                out.println(carid);
        try {
            int userid = 0 ;
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/desem6", "root", "");
           
            String sql1 = "update carinformation set status='active' where carid = ? ";
                PreparedStatement p1 = con.prepareStatement(sql1);
                p1.setInt(1, carid);
            int count = p1.executeUpdate();
            
           
            String sql2 = "update booking set at='owner' where carid = ? ";
                PreparedStatement p2 = con.prepareStatement(sql2); 
                p2.setInt(1, carid);
            count += p2.executeUpdate();
             String sql11 = "update carinformation set clientid = 0 where carid = ? ";
                PreparedStatement p11 = con.prepareStatement(sql11);
                p11.setInt(1, carid);
            count += p11.executeUpdate();
            if (count > 2) {
                session.setAttribute("returncheck", "true");
                dispatcher = request.getRequestDispatcher("profile.jsp");
                out.println("all run ok");
            } else {
                session.setAttribute("returncheck", "false");
                dispatcher = request.getRequestDispatcher("error.jsp");

            }

        } catch (Exception e) {
            e.getMessage();
            session.setAttribute("returncheck", "false");
            dispatcher = request.getRequestDispatcher("error.jsp");

        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(registration.class.getName()).log(Level.SEVERE, null, ex);
            }

            dispatcher.forward(request, response);

        }

    }
    
}
