
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//  @WebServlet("/login")
public class login extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        RequestDispatcher dispatcher = null;
        Connection con = null;
        HttpSession session = request.getSession();

        try {

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/desem6", "root", "");

            String query = "select * from user where email = ? and password = ? ";

            PreparedStatement stmt = con.prepareStatement(query);

            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                session.setAttribute("name", rs.getString("username"));
                session.setAttribute("gender", rs.getString("gender"));
                session.setAttribute("fristname", rs.getString("fristname"));
                session.setAttribute("lastname", rs.getString("lastname"));
                session.setAttribute("userid", rs.getString("userid"));
                session.setAttribute("email", rs.getString("email"));
                session.setAttribute("userid", rs.getString("userid"));
                session.setAttribute("logincheck","true");
                dispatcher = request.getRequestDispatcher("index.jsp");
            } else {
                session.setAttribute("logincheck","false");
                dispatcher = request.getRequestDispatcher("profile.jsp");

            }
           

        } catch (Exception e) {
            e.printStackTrace();
            
                dispatcher = request.getRequestDispatcher("error.jsp");

        }
        finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(registration.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        dispatcher.forward(request, response);

        }

    }
}
